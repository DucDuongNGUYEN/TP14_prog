public class StrategieSuivantSimple extends StrategieSuivant{
    @Override
    void suivant(LecteurMail l) {
        l.suivant();
    }
}
