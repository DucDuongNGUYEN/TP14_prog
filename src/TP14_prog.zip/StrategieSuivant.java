public abstract class StrategieSuivant {
    abstract void suivant (LecteurMail l);
}
