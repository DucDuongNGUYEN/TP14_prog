public class Serveur {
    void envoie(Mail m){}
}
